
var transformProp = "transform";

var pfx = ["webkit", "moz", "ms", "o", ""];
function RunPrefixMethod(obj, method) {
	var p = 0, m, t;
	while (p < pfx.length && !obj[m]) {
		m = method;
		if (pfx[p] == "") {
			m = m.substr(0,1).toLowerCase() + m.substr(1);
		}
		m = pfx[p] + m;
		t = typeof obj[m];
		if (t != "undefined") {
			pfx = [pfx[p]];
			return (t == "function" ? obj[m]() : obj[m]);
		}
		p++;
	}
}

function detectVendorPrefixes() {
      if (document.body.style.webkitTransform !== undefined) {
        transformProp = "webkitTransform";
      }
      else if (document.body.style.mozTransform !== undefined) {
            transformProp = "mozTransform";
      }
      else if (document.body.style.msTransform !== undefined) {
            transformProp = "msTransform";
      }
      else if (document.body.style.oTransform !== undefined) {
            transformProp = "oTransform";
      }
      else if (document.body.style.transform !== undefined) {
          transformProp = "transform"; 
      }
      else {
        throw("error no tranform property");
      }
};