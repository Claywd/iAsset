
0.1.0 / 2014-11-11 
==================

  * load moment-timezone from bower, optionally take in array of tz
  * Added ignored files/directories to bower.json
  * Updated to use new moment-timezone

0.0.4 / 2013-08-19 
==================

  * support for jquery 1.* and bower 1.0

0.0.3 / 2013-08-13 
==================

  * Added formatName filter for timezone names.

0.0.2 / 2013-08-07 
==================

  * Merge remote-tracking branch 'origin/feature/getCurrentOffset'
  * Timezones ordered.
  * Added ability to call methods from plugin. Added getCurrentOffset.

0.0.1 / 2013-08-05 
==================

  * Merge branch 'feature/moment-timezone'
  * renamed timezone-select to timezones
  * Pass in zone data instead of assuming momentTZData.
  * Now uses tz data which is located in momentTZData.
  * updated build process
  * Added moment-timezone support.
  * Adding demo to readme
  * Library functionality
  * boilerplate
