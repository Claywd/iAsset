/**
 * Fix that links in standalone webapps on ios open in Safari.
 */
$(document).on('click', 'a', function(e) {
    if ($(this).attr('target') !== '_blank') {
        e.preventDefault();
    	var href = $(this).attr('href');
    	if (href !== undefined) {
        	window.location = href;
    	}
    }
});
