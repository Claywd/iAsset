#!/bin/sh

# This script calls the html_autoversion tool to generate checksums
# for all files which are referenced from a HTML file.

# Note: the original files won't be touched, instead the caller should
# merge the generated files into the original ones with a diff tool.

PRG=../html_autoversion/html_autoversion

if [ ! -e "${PRG}" ]; then
	echo "$PRG not found"
	exit 1
fi

OUTDIR="/tmp/webapp-chksum-"$(date --iso-8601)

mkdir -p $OUTDIR

for f in `ls *.html`; do 
	echo "write $OUTDIR/$f"
	$PRG $f > $OUTDIR/$f
done
